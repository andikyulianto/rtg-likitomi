<?php

$lang['title']				= "Partners | Likitomi ERP";
$lang['all_partners']		= "Partners ทั้งหมด";
$lang['customers']			= "ลูกค้า";
$lang['suppliers']			= "Suppliers";
$lang['archive']			= "Archive";
$lang['most_used_partners'] = "Most Used";	
$lang['recently_used_partners'] = "Partners รายใหม่";	
$lang['search_result']="ผลการค้นหา";

$lang['msg_selectpartners']	= "เลือก Partners จากเมนูที่แสดงอยู่ทางด้านซ้ายมือ";
$lang['msg_nothingtoedit']	= "Nothing to Edit. Please select one of the partners.";
$lang['msg_nothingtodelete']	= "Nothing to Delete. Please select one of the partners.";
$lang['ajax_loading_partners'] = "กำลังโหลดข้อมูล Partners..";
$lang['ajax_loading_details'] = "กำลังโหลดข้อมูลรายละเอียดของ Partner ..";
$lang['ajax_updating_details'] = "กำลังอัพเดตข้อมูลรายละเอียดของ Partner ..";
$lang['ajax_saving_details'] = "Saving Partner Details..";

$lang['alt_companylogo'] = "โลโก้ของบริษัท";
$lang['search_partners']	="ค้นหา Partners...";
/* Interface  */
$lang['name'] = "ชื่อ (ภาษาอังกฤษ)";
$lang['type'] = "ชนิด";
$lang['name_thai'] = "ชื่อ (ภาษาไทย)";
$lang['supplier_code']= "Supplier Code";
$lang['credit_term']= "Credit Term";
$lang['ph_office'] = "เบอร์โทรศัพท์";
$lang['fax'] = "Fax";
$lang['other_phone'] = "เบอร์โทรศัพท์อื่นๆ";
$lang['email'] = "อีเมล์";
$lang['web'] = "เว็บไซต์";
$lang['contact_title'] = "Contact Title";
$lang['contact_person'] = "บุคคลที่สามารถติดต่อได้";
$lang['billing'] = "ไปยัง";
$lang['date_entered'] = "วันที่ใส่ข้อมูล";
$lang['date_mod'] = "วันที่แก้ไข";
$lang['desc'] = "รายละเอียด";
$lang['customer']			= "ลูกค้า";
$lang['supplier']			= "Supplier";

//Buttons
$lang['edit'] 		= "แก้ไข";
$lang['update'] 	= "อัพเดต";
$lang['cancel'] 	= "ยกเลิก";
$lang['save'] 		= "จัดเก็บข้อมูล";
$lang['archive'] 	= "Archive";
$lang['add'] 		= "เพิ่ม";
?>
