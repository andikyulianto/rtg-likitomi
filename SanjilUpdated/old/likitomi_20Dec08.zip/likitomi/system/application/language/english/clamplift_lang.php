<?php

$lang['title']			= "Clamplift | Likitomi ERP";
$lang['Now']			= "Now";
$lang['Morning']		= "Morning";
$lang['Afternoon']		= "Afternoon";
$lang['Evening']		= "Evening";
$lang['Late_Night']		= "Late Night";
$lang['ajax_loading_tasklist']= "Loading Clamplift Task";

/* End of file ftp_lang.php */
/* Location: ./system/language/english/clamplift_lang.php 
 */
 


?>
