<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant base_url - assumed 'base_url' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 700
ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant index - assumed 'index' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 701
ERROR - 2008-08-26 15:00:52 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 701
ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 701
ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant Partners - assumed 'Partners' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 701
ERROR - 2008-08-26 15:00:52 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 701
ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant base_url - assumed 'base_url' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 702
ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant index - assumed 'index' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 703
ERROR - 2008-08-26 15:00:52 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 703
ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant php - assumed 'php' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 703
ERROR - 2008-08-26 15:00:52 --> Severity: Notice  --> Use of undefined constant Products - assumed 'Products' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 703
ERROR - 2008-08-26 15:00:52 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 703
ERROR - 2008-08-26 15:01:16 --> Severity: Notice  --> Use of undefined constant base_url - assumed 'base_url' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 700
ERROR - 2008-08-26 15:01:16 --> Severity: Notice  --> Use of undefined constant base_url - assumed 'base_url' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 701
ERROR - 2008-08-26 15:01:16 --> Severity: Notice  --> Use of undefined constant base_url - assumed 'base_url' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 702
ERROR - 2008-08-26 15:01:16 --> Severity: Notice  --> Use of undefined constant base_url - assumed 'base_url' /opt/Aptana Studio/php/likitomi/system/application/views/products/products.php 703
ERROR - 2008-08-26 15:20:37 --> 404 Page Not Found --> welcome
ERROR - 2008-08-26 20:32:51 --> 404 Page Not Found --> welcome
ERROR - 2008-08-26 22:50:58 --> 404 Page Not Found --> welcome
ERROR - 2008-08-26 22:51:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-26 22:51:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 22:57:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-26 22:57:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 22:57:11 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-26 22:57:11 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 22:57:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-26 22:57:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 22:58:12 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productdetail.php 13
ERROR - 2008-08-26 22:58:12 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productdetail.php 13
ERROR - 2008-08-26 22:58:12 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 13
ERROR - 2008-08-26 22:58:12 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 13
ERROR - 2008-08-26 22:58:12 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 65
ERROR - 2008-08-26 22:58:12 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 68
ERROR - 2008-08-26 22:58:15 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productdetail.php 13
ERROR - 2008-08-26 22:58:15 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productdetail.php 13
ERROR - 2008-08-26 22:58:15 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 13
ERROR - 2008-08-26 22:58:15 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 13
ERROR - 2008-08-26 22:58:15 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 65
ERROR - 2008-08-26 22:58:15 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 68
ERROR - 2008-08-26 23:01:47 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 23:01:47 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-26 23:02:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 23:02:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-26 23:06:32 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-26 23:06:32 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 23:06:47 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-26 23:06:47 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-26 23:06:50 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 338
ERROR - 2008-08-26 23:06:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 2
ERROR - 2008-08-26 23:06:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 3
ERROR - 2008-08-26 23:06:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 4
ERROR - 2008-08-26 23:06:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 5
ERROR - 2008-08-26 23:06:50 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 6
ERROR - 2008-08-26 23:10:31 --> 404 Page Not Found --> products/report
