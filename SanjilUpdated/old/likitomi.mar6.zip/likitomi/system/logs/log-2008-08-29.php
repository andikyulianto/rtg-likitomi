<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-29 00:05:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 79
ERROR - 2008-08-29 00:05:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 94
ERROR - 2008-08-29 00:06:18 --> Severity: Warning  --> array_unique() [<a href='function.array-unique'>function.array-unique</a>]: The argument should be an array /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 54
ERROR - 2008-08-29 00:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 79
ERROR - 2008-08-29 00:06:18 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 94
ERROR - 2008-08-29 02:02:07 --> Severity: Notice  --> Undefined variable: filter /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 66
ERROR - 2008-08-29 02:02:07 --> Severity: Notice  --> Undefined variable: values /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 71
ERROR - 2008-08-29 02:11:07 --> Severity: Notice  --> Undefined variable: value /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 26
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Undefined variable: resultDeliverys /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 15
ERROR - 2008-08-29 07:36:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 15
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:36:49 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:37:19 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:37:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:38:07 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:38:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:40:01 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:40:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:40:09 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Use of undefined constant length - assumed 'length' /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 67
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:43:00 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:45:22 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:45:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:45:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:46:39 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:47:02 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:49:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:51:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 20
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 23
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Undefined variable: delivery /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 07:51:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 24
ERROR - 2008-08-29 09:53:11 --> Severity: Notice  --> Undefined variable: resultKeyin /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 31
ERROR - 2008-08-29 09:53:56 --> Severity: Notice  --> Undefined variable: key /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 34
ERROR - 2008-08-29 09:53:56 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 34
ERROR - 2008-08-29 09:53:56 --> Severity: Notice  --> Undefined variable: key /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 35
ERROR - 2008-08-29 09:53:56 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 35
ERROR - 2008-08-29 09:54:11 --> Severity: Notice  --> Undefined variable: key /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 34
ERROR - 2008-08-29 09:54:11 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 34
ERROR - 2008-08-29 09:54:11 --> Severity: Notice  --> Undefined variable: key /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 35
ERROR - 2008-08-29 09:54:11 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 35
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:00:33 --> Severity: Notice  --> Undefined property:  stdClass::$pwidth_mm /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 40
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:01:52 --> Severity: Notice  --> Undefined property:  stdClass::$flute /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 44
ERROR - 2008-08-29 10:25:51 --> Query error: 
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 10:33:03 --> Severity: Notice  --> Undefined property:  stdClass::$next /opt/Aptana Studio/php/likitomi/system/application/views/planning/keyin.php 66
ERROR - 2008-08-29 11:34:07 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 11:34:07 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 13:17:40 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-08-29 13:17:40 --> Unable to connect to the database
ERROR - 2008-08-29 13:20:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:20:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:20:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:20:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:20:32 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:20:32 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:20:33 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:20:33 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:20:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:20:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:20:36 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:20:36 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:20:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:20:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:35:57 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 13:35:57 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 13:36:47 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 13:36:47 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 13:37:21 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-29 13:37:21 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 102
ERROR - 2008-08-29 13:42:31 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 13:42:31 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 14:40:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_name /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 22
ERROR - 2008-08-29 15:06:45 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
ERROR - 2008-08-29 15:06:45 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 20
