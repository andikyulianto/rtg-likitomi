<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-11 16:48:16 --> 404 Page Not Found --> savepaper
ERROR - 2008-09-11 17:12:07 --> Severity: Notice  --> Undefined variable: invoiceArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 433
ERROR - 2008-09-11 17:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
ERROR - 2008-09-11 17:12:07 --> Severity: Notice  --> Undefined variable: paperCodeArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 439
ERROR - 2008-09-11 17:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
ERROR - 2008-09-11 17:12:07 --> Severity: Notice  --> Undefined variable: suppliersArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 445
ERROR - 2008-09-11 17:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
ERROR - 2008-09-11 17:12:07 --> Severity: Notice  --> Undefined variable: addedDateArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 451
ERROR - 2008-09-11 17:12:07 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
