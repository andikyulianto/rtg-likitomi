<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-02 14:17:29 --> Severity: User Warning  --> Ending date/time is earlier than the start date/time /opt/Aptana Studio/php/likitomi/system/application/views/planning/search.php 204
ERROR - 2008-09-02 14:17:29 --> Severity: User Warning  --> Ending date/time is earlier than the start date/time /opt/Aptana Studio/php/likitomi/system/application/views/planning/search.php 204
ERROR - 2008-09-02 14:17:29 --> Severity: User Warning  --> Ending date/time is earlier than the start date/time /opt/Aptana Studio/php/likitomi/system/application/views/planning/search.php 204
ERROR - 2008-09-02 14:17:29 --> Severity: User Warning  --> Ending date/time is earlier than the start date/time /opt/Aptana Studio/php/likitomi/system/application/views/planning/search.php 204
ERROR - 2008-09-02 14:17:29 --> Severity: User Warning  --> Ending date/time is earlier than the start date/time /opt/Aptana Studio/php/likitomi/system/application/views/planning/search.php 204
ERROR - 2008-09-02 14:17:29 --> Severity: User Warning  --> Ending date/time is earlier than the start date/time /opt/Aptana Studio/php/likitomi/system/application/views/planning/search.php 204
ERROR - 2008-09-02 14:49:51 --> 404 Page Not Found --> images
ERROR - 2008-09-02 14:49:55 --> 404 Page Not Found --> images
ERROR - 2008-09-02 14:49:56 --> 404 Page Not Found --> images
ERROR - 2008-09-02 14:50:25 --> 404 Page Not Found --> images
ERROR - 2008-09-02 14:50:52 --> 404 Page Not Found --> planning/undefinedundefined
ERROR - 2008-09-02 14:51:00 --> 404 Page Not Found --> planning/undefinedundefined
ERROR - 2008-09-02 14:51:11 --> 404 Page Not Found --> planning/undefinedundefined
ERROR - 2008-09-02 16:48:55 --> Severity: Warning  --> Missing argument 1 for SalesOrder::index() /opt/Aptana Studio/php/likitomi/system/application/controllers/salesorder.php 13
ERROR - 2008-09-02 16:48:55 --> Severity: Notice  --> Undefined variable: salesorder /opt/Aptana Studio/php/likitomi/system/application/controllers/salesorder.php 21
ERROR - 2008-09-02 16:48:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 2
ERROR - 2008-09-02 16:48:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 3
ERROR - 2008-09-02 16:48:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 4
ERROR - 2008-09-02 16:48:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 5
ERROR - 2008-09-02 16:48:55 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 6
ERROR - 2008-09-02 17:09:46 --> Severity: Warning  --> Missing argument 1 for Planning_model::getProduct_Partner(), called in /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php on line 88 and defined /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 34
ERROR - 2008-09-02 17:09:46 --> Severity: Notice  --> Undefined variable: pid /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 37
ERROR - 2008-09-02 17:09:46 --> Query error: 
ERROR - 2008-09-02 17:19:12 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 105
ERROR - 2008-09-02 17:19:41 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 105
ERROR - 2008-09-02 17:22:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 21
ERROR - 2008-09-02 18:19:45 --> Severity: Warning  --> Missing argument 1 for Planning::getDeliveryHistory() /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 109
ERROR - 2008-09-02 18:19:45 --> Severity: Notice  --> Undefined variable: deliveryList /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 112
ERROR - 2008-09-02 18:19:45 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 112
ERROR - 2008-09-02 18:19:45 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 114
ERROR - 2008-09-02 18:21:11 --> Severity: Notice  --> Undefined variable: deliveryList /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 113
ERROR - 2008-09-02 18:21:11 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 113
ERROR - 2008-09-02 18:21:11 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 115
ERROR - 2008-09-02 18:33:26 --> Severity: Notice  --> Undefined variable: history /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/deliveryhistory.php 8
ERROR - 2008-09-02 18:34:04 --> Severity: Notice  --> Undefined variable: history /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/deliveryhistory.php 8
ERROR - 2008-09-02 18:34:17 --> Severity: Notice  --> Undefined variable: history /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/deliveryhistory.php 8
ERROR - 2008-09-02 18:38:44 --> Severity: Notice  --> Undefined variable: showheader /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/deliveryhistory.php 6
