<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-29 18:06:13 --> Severity: Notice  --> Undefined property:  stdClass::$created_on /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 147
ERROR - 2008-10-29 18:06:50 --> Severity: Notice  --> Undefined property:  stdClass::$created_on /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 147
ERROR - 2008-10-29 18:07:56 --> Severity: Notice  --> Undefined property:  stdClass::$created_on /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 147
ERROR - 2008-10-29 18:09:41 --> Severity: Notice  --> Undefined property:  stdClass::$created_on /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 147
