<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-11-28 13:09:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 5
ERROR - 2008-11-28 13:09:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 5
ERROR - 2008-11-28 13:12:05 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 5
ERROR - 2008-11-28 13:12:27 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 5
ERROR - 2008-11-28 13:12:43 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 5
ERROR - 2008-11-28 13:12:58 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 5
ERROR - 2008-11-28 13:12:58 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 5
ERROR - 2008-11-28 13:14:08 --> Severity: Notice  --> Undefined property:  stdClass::$cnt /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-11-28 13:39:27 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:27 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:27 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:27 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:27 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:27 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:27 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:38 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:38 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:38 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:38 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:38 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:38 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:39:38 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 7
ERROR - 2008-11-28 13:41:13 --> Severity: Notice  --> Undefined property:  stdClass::$opdate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-11-28 13:44:29 --> 404 Page Not Found --> clampliftmanager
ERROR - 2008-11-28 13:44:44 --> 404 Page Not Found --> clampliftmanager
ERROR - 2008-11-28 13:44:50 --> 404 Page Not Found --> clampliftmanager
ERROR - 2008-11-28 13:45:15 --> 404 Page Not Found --> clampliftmanager
ERROR - 2008-11-28 13:45:37 --> 404 Page Not Found --> clampliftmanager
