<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-11-03 15:29:08 --> Severity: Notice  --> Undefined property:  stdClass::$delivery_qty /opt/Aptana Studio/php/likitomi/system/application/views/planning/productstatus.php 36
ERROR - 2008-11-03 15:29:08 --> Severity: Notice  --> Undefined property:  stdClass::$delivery_qty /opt/Aptana Studio/php/likitomi/system/application/views/planning/productstatus.php 36
