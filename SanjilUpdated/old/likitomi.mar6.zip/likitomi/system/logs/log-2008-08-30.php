<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-30 13:47:00 --> 404 Page Not Found --> welcome
ERROR - 2008-08-30 14:29:06 --> 404 Page Not Found --> welcome
ERROR - 2008-08-30 14:29:08 --> 404 Page Not Found --> welcome
ERROR - 2008-08-30 14:29:10 --> 404 Page Not Found --> welcome
ERROR - 2008-08-30 14:32:37 --> 404 Page Not Found --> welcome
ERROR - 2008-08-30 23:51:57 --> 404 Page Not Found --> welcome
