<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 10:21:52 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 11:15:00 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-23 11:15:00 --> Severity: Notice  --> Use of undefined constant ขณะนี้ - assumed 'ขณะนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-23 11:15:00 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-23 11:15:00 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-23 11:15:00 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-23 11:15:00 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-23 11:15:00 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:41 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:27:42 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 13:50:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 13:58:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 15:24:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 15:47:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:13:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:16:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:17:51 --> Query error: 
ERROR - 2009-02-23 18:18:12 --> Query error: 
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:18:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-23 18:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 104
ERROR - 2009-02-23 18:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 105
ERROR - 2009-02-23 18:18:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 106
