<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 02:24:47 --> Severity: Notice  --> Undefined variable: MAX /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/scan.php 76
ERROR - 2008-11-22 09:35:41 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'im.ait.ac.th' (4) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-11-22 09:35:41 --> Unable to connect to the database
ERROR - 2008-11-22 09:35:50 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'im.ait.ac.th' (4) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-11-22 09:35:50 --> Unable to connect to the database
ERROR - 2008-11-22 14:54:24 --> Query error: 
ERROR - 2008-11-22 14:55:18 --> Query error: 
ERROR - 2008-11-22 14:56:46 --> Query error: 
ERROR - 2008-11-22 14:56:51 --> Query error: 
