<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: partner_isdeleted /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 9
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 11:32:38 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: partner_isdeleted /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 9
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 11:33:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: partner_isdeleted /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 9
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 11:54:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 11:55:40 --> Query error: 
ERROR - 2008-10-20 11:55:55 --> Query error: 
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: partner_isdeleted /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 9
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 11:56:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-20 17:10:36 --> 404 Page Not Found --> _dc
ERROR - 2008-10-20 17:10:52 --> 404 Page Not Found --> _dc
ERROR - 2008-10-20 17:16:12 --> 404 Page Not Found --> _dc
ERROR - 2008-10-20 17:18:01 --> 404 Page Not Found --> planning/true
