<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 118
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 119
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 120
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 118
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 119
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 120
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 118
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 119
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 120
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 118
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 119
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 120
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 118
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 119
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 120
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 118
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 119
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 120
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 118
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 119
ERROR - 2008-08-25 00:45:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 120
ERROR - 2008-08-25 01:56:16 --> Severity: Warning  --> Missing argument 2 for Products_model::getDeliveryList(), called in /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php on line 387 and defined /opt/Aptana Studio/php/likitomi/system/application/models/products_model.php 285
ERROR - 2008-08-25 01:56:16 --> Severity: Notice  --> Undefined variable: sales_order /opt/Aptana Studio/php/likitomi/system/application/models/products_model.php 288
ERROR - 2008-08-25 14:25:08 --> Query error: 
ERROR - 2008-08-25 14:25:47 --> Query error: 
ERROR - 2008-08-25 16:09:31 --> Severity: Notice  --> Undefined variable: resultPartners /opt/Aptana Studio/php/likitomi/system/application/views/products/productdetail.php 213
ERROR - 2008-08-25 16:09:32 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/productdetail.php 213
ERROR - 2008-08-25 18:36:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:334) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 2
ERROR - 2008-08-25 18:36:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:334) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 3
ERROR - 2008-08-25 18:36:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:334) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 4
ERROR - 2008-08-25 18:36:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:334) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 5
ERROR - 2008-08-25 18:36:16 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:334) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 6
ERROR - 2008-08-25 19:20:29 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 21
ERROR - 2008-08-25 19:20:29 --> Severity: Notice  --> Undefined variable: productDetails /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 55
ERROR - 2008-08-25 19:20:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 55
ERROR - 2008-08-25 19:20:29 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 121
ERROR - 2008-08-25 19:20:29 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 122
ERROR - 2008-08-25 19:20:29 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 123
ERROR - 2008-08-25 19:20:29 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 138
ERROR - 2008-08-25 19:20:29 --> Severity: Notice  --> Undefined variable: productDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-25 19:20:29 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-25 19:21:14 --> Severity: Notice  --> Undefined variable: productDetails /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 55
ERROR - 2008-08-25 19:21:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 55
ERROR - 2008-08-25 19:21:14 --> Severity: Notice  --> Undefined variable: productDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-25 19:21:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-25 19:21:40 --> Severity: Notice  --> Undefined variable: productDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-25 19:21:40 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
