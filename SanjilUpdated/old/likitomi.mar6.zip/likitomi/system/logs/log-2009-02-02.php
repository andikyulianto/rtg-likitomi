<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-02 09:40:46 --> 404 Page Not Found --> users/2
ERROR - 2009-02-02 09:42:17 --> 404 Page Not Found --> users/2
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 09:48:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:05:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:08:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:11:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:11:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:11:54 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:17:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:25:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:27:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:29:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:31:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:33:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:35:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:37:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 10:39:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-02 17:31:11 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\likitomi\system\application\controllers\planning.php 145
