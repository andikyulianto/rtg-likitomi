<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:43:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:50:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:51:09 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:51:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 08:57:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 09:20:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 09:24:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 104
ERROR - 2009-02-13 09:24:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 105
ERROR - 2009-02-13 09:24:28 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 106
ERROR - 2009-02-13 09:25:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\salesorder.php 91
ERROR - 2009-02-13 09:25:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 104
ERROR - 2009-02-13 09:25:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 105
ERROR - 2009-02-13 09:25:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 106
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 09:30:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 09:45:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 104
ERROR - 2009-02-13 09:45:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 105
ERROR - 2009-02-13 09:45:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 106
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 09:47:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:05:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:08:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:11:07 --> Query error: 
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:15:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:18:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:27:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:47:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:49:19 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:53:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 10:55:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:00:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:03:16 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:05:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:07:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:09:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:14:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:19:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:21:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:23:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:29:33 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 11:29:34 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 11:29:34 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 11:29:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:29:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:45:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:46:47 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:56:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:57:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 14:59:40 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:01:53 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:18:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:20:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 15:27:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:06:28 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:06:29 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:19:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:30:57 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 16:33:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:16:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:16:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:16:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:16:03 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:16:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:16:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:17:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:18:08 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:18:45 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:25:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:40:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:44:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 17:44:31 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 17:44:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 17:44:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 18:09:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 18:16:38 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-13 18:24:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
