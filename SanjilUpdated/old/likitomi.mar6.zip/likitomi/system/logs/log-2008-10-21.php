<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-21 14:50:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'im.ait.ac.th' (65) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-21 14:50:29 --> Unable to connect to the database
