<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-08 15:52:24 --> Unable to load the requested class: db_session
ERROR - 2008-10-08 16:02:05 --> Unable to load the requested class: db_session
ERROR - 2008-10-08 16:02:49 --> Unable to load the requested class: db_session
ERROR - 2008-10-08 16:04:08 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:08:14 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:09:37 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:10:02 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:10:04 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:10:11 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:11:45 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:12:10 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:12:13 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:16:13 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:16:37 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:25:41 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:26:18 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:26:49 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:27:06 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:27:31 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:30:38 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:31:48 --> Db_session: sessions requires a database
ERROR - 2008-10-08 16:33:02 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:20:13 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:20:20 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:20:20 --> Query error: 
ERROR - 2008-10-08 18:20:54 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:20:54 --> Query error: 
ERROR - 2008-10-08 18:21:48 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:21:51 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:21:51 --> Query error: 
ERROR - 2008-10-08 18:21:55 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:21:55 --> Query error: 
ERROR - 2008-10-08 18:22:24 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:22:26 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:22:26 --> Query error: 
ERROR - 2008-10-08 18:23:05 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:23:05 --> Query error: 
ERROR - 2008-10-08 18:29:46 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:29:47 --> Severity: Notice  --> Undefined property:  stdClass::$activated /opt/Aptana Studio/php/likitomi/system/application/libraries/Authlib.php 284
ERROR - 2008-10-08 18:29:47 --> Severity: Notice  --> Undefined index:  user_agent /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 297
ERROR - 2008-10-08 18:29:47 --> Severity: Notice  --> Undefined index:  ip_address /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 298
ERROR - 2008-10-08 18:29:47 --> Severity: Notice  --> Undefined index:  session_id /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 304
ERROR - 2008-10-08 18:29:47 --> Query error: 
ERROR - 2008-10-08 18:33:14 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:33:14 --> Severity: Notice  --> Undefined index:  user_agent /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 297
ERROR - 2008-10-08 18:33:14 --> Severity: Notice  --> Undefined index:  ip_address /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 298
ERROR - 2008-10-08 18:33:14 --> Severity: Notice  --> Undefined index:  session_id /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 304
ERROR - 2008-10-08 18:33:14 --> Query error: 
ERROR - 2008-10-08 18:33:19 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:33:25 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:33:25 --> Severity: Notice  --> Undefined index:  user_agent /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 297
ERROR - 2008-10-08 18:33:25 --> Severity: Notice  --> Undefined index:  ip_address /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 298
ERROR - 2008-10-08 18:33:25 --> Severity: Notice  --> Undefined index:  session_id /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 304
ERROR - 2008-10-08 18:33:25 --> Query error: 
ERROR - 2008-10-08 18:36:18 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:36:18 --> Severity: Notice  --> Undefined index:  user_agent /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 297
ERROR - 2008-10-08 18:36:18 --> Severity: Notice  --> Undefined index:  ip_address /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 298
ERROR - 2008-10-08 18:36:18 --> Severity: Notice  --> Undefined index:  session_id /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 304
ERROR - 2008-10-08 18:36:18 --> Query error: 
ERROR - 2008-10-08 18:38:30 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:53:58 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:54:08 --> Db_session: sessions requires a database
ERROR - 2008-10-08 18:54:08 --> Severity: Notice  --> Undefined index:  user_agent /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 297
ERROR - 2008-10-08 18:54:08 --> Severity: Notice  --> Undefined index:  ip_address /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 298
ERROR - 2008-10-08 18:54:08 --> Severity: Notice  --> Undefined index:  session_id /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 304
ERROR - 2008-10-08 18:54:08 --> Query error: 
ERROR - 2008-10-08 20:01:25 --> The path to the image is not correct.
ERROR - 2008-10-08 20:01:25 --> Your server does not support the GD function required to process this type of image.
ERROR - 2008-10-08 20:01:32 --> 404 Page Not Found --> auth/forgotten_password_index
ERROR - 2008-10-08 20:14:32 --> 404 Page Not Found --> auth_loout_success_action
ERROR - 2008-10-08 20:14:38 --> 404 Page Not Found --> auth_loout_success_action
