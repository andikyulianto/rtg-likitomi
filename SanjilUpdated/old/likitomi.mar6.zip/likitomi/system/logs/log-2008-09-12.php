<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-12 12:48:17 --> Severity: Notice  --> Undefined variable: invoiceArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 433
ERROR - 2008-09-12 12:48:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
ERROR - 2008-09-12 12:48:17 --> Severity: Notice  --> Undefined variable: paperCodeArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 439
ERROR - 2008-09-12 12:48:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
ERROR - 2008-09-12 12:48:17 --> Severity: Notice  --> Undefined variable: suppliersArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 445
ERROR - 2008-09-12 12:48:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
ERROR - 2008-09-12 12:48:17 --> Severity: Notice  --> Undefined variable: addedDateArray /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 451
ERROR - 2008-09-12 12:48:17 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/stock.php 498
ERROR - 2008-09-12 21:05:57 --> 404 Page Not Found --> welcome
