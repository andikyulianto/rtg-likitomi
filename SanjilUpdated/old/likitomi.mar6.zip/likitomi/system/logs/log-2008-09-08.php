<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-08 01:09:19 --> Severity: Notice  --> Undefined variable: tomorrow /opt/Aptana Studio/php/likitomi/system/application/views/planning/search.php 477
ERROR - 2008-09-08 12:37:28 --> Severity: Notice  --> Undefined variable: item /opt/Aptana Studio/php/likitomi/system/application/views/planning/totalplanning.php 33
ERROR - 2008-09-08 12:45:07 --> Query error: 
ERROR - 2008-09-08 12:55:40 --> Severity: Notice  --> Undefined property:  Planning::$Salesorder_model /opt/Aptana Studio/php/likitomi/system/application/controllers/planning.php 157
ERROR - 2008-09-08 14:06:00 --> Severity: Notice  --> Undefined property:  Planning_model::$tblName /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 71
ERROR - 2008-09-08 14:10:24 --> Severity: Notice  --> Undefined property:  Planning_model::$tblName /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 71
