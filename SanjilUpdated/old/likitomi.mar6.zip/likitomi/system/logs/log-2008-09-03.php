<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-03 01:54:28 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-09-03 01:54:28 --> Unable to connect to the database
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  p_width_inch /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 31
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  t_length /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 32
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  p_width_inch /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 31
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  t_length /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 32
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  p_width_inch /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 31
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  t_length /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 32
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  p_width_inch /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 31
ERROR - 2008-09-03 10:35:40 --> Severity: Notice  --> Undefined index:  t_length /opt/Aptana Studio/php/likitomi/system/application/views/planning/deliverytable.php 32
