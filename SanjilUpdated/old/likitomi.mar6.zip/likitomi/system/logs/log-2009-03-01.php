<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-03-01 11:44:38 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on '192.168.1.9' (4) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2009-03-01 11:44:38 --> Unable to connect to the database
ERROR - 2009-03-01 12:18:39 --> 404 Page Not Found --> partners/get
ERROR - 2009-03-01 12:18:43 --> 404 Page Not Found --> partners/get
