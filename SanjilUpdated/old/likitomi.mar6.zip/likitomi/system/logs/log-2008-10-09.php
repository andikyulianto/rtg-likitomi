<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-09 15:19:45 --> 404 Page Not Found --> installer
ERROR - 2008-10-09 17:25:52 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 17:25:53 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 17:26:01 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 17:37:35 --> 404 Page Not Found --> products/admin
ERROR - 2008-10-09 17:40:20 --> 404 Page Not Found --> products/admin
ERROR - 2008-10-09 17:45:28 --> 404 Page Not Found --> products/admin
ERROR - 2008-10-09 17:45:30 --> 404 Page Not Found --> products/admin
ERROR - 2008-10-09 18:07:14 --> Severity: Notice  --> Undefined index:  rules /opt/Aptana Studio/php/likitomi/system/application/controllers/admin/admins.php 378
ERROR - 2008-10-09 19:08:06 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:14:26 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:25:57 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:26:01 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:30:56 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:32:17 --> 404 Page Not Found --> users/2
ERROR - 2008-10-09 19:32:24 --> 404 Page Not Found --> users/2
ERROR - 2008-10-09 19:32:28 --> 404 Page Not Found --> users/2
ERROR - 2008-10-09 19:33:37 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:33:50 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:38:48 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:39:42 --> 404 Page Not Found --> admins
ERROR - 2008-10-09 19:41:21 --> 404 Page Not Found --> admins
ERROR - 2008-10-09 19:42:01 --> 404 Page Not Found --> admins
ERROR - 2008-10-09 19:42:17 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:42:18 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:42:46 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:42:47 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-09 19:42:54 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
