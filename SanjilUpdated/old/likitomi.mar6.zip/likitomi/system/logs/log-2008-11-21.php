<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-11-21 00:09:55 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftmanager.php 7
ERROR - 2008-11-21 00:23:35 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftmanager.php 7
ERROR - 2008-11-21 01:06:03 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftmanager.php 7
ERROR - 2008-11-21 01:08:47 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftmanager.php 7
ERROR - 2008-11-21 01:10:21 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftmanager.php 7
ERROR - 2008-11-21 01:11:27 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftmanager.php 7
ERROR - 2008-11-21 01:11:57 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftmanager.php 7
ERROR - 2008-11-21 01:30:03 --> Severity: Notice  --> Undefined property:  Clampliftmanger::$Planning_model /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 159
ERROR - 2008-11-21 01:45:28 --> Query error: 
ERROR - 2008-11-21 01:46:23 --> Query error: 
ERROR - 2008-11-21 01:57:39 --> Severity: Notice  --> Undefined variable: DB1 /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 98
ERROR - 2008-11-21 01:57:51 --> Severity: Notice  --> Undefined variable: DB1 /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 98
ERROR - 2008-11-21 02:11:38 --> Severity: Notice  --> Undefined variable: choosendate /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 106
ERROR - 2008-11-21 02:11:38 --> Severity: Warning  --> array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #2 is not an array /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 106
ERROR - 2008-11-21 02:11:55 --> Severity: Warning  --> array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #2 is not an array /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 106
ERROR - 2008-11-21 02:13:17 --> Severity: Warning  --> array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #2 is not an array /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 106
ERROR - 2008-11-21 02:13:26 --> Severity: Warning  --> array_merge() [<a href='function.array-merge'>function.array-merge</a>]: Argument #2 is not an array /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 106
ERROR - 2008-11-21 02:22:22 --> Query error: 
ERROR - 2008-11-21 08:22:03 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 103
ERROR - 2008-11-21 08:39:15 --> Severity: Notice  --> Undefined variable: used_df /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 123
ERROR - 2008-11-21 08:40:06 --> Query error: 
ERROR - 2008-11-21 08:41:53 --> Severity: Notice  --> Undefined variable: used_df /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 122
ERROR - 2008-11-21 08:42:22 --> Severity: Notice  --> Undefined property:  stdClass::$cut2 /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 131
ERROR - 2008-11-21 08:42:22 --> Query error: 
ERROR - 2008-11-21 08:43:16 --> Severity: Notice  --> Undefined property:  stdClass::$cut2 /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 131
ERROR - 2008-11-21 08:43:16 --> Query error: 
ERROR - 2008-11-21 08:43:40 --> Severity: Notice  --> Undefined property:  stdClass::$cut2 /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 131
ERROR - 2008-11-21 08:43:40 --> Query error: 
ERROR - 2008-11-21 09:21:51 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 110
ERROR - 2008-11-21 09:21:51 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 111
ERROR - 2008-11-21 09:21:51 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$partner_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 112
ERROR - 2008-11-21 09:21:51 --> Query error: 
ERROR - 2008-11-21 09:24:47 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 115
ERROR - 2008-11-21 09:24:47 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 116
ERROR - 2008-11-21 09:24:47 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$partner_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 117
ERROR - 2008-11-21 09:24:47 --> Query error: 
ERROR - 2008-11-21 09:27:41 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 115
ERROR - 2008-11-21 09:27:41 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 116
ERROR - 2008-11-21 09:27:41 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$partner_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 117
ERROR - 2008-11-21 09:27:41 --> Query error: 
ERROR - 2008-11-21 09:28:40 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 115
ERROR - 2008-11-21 09:28:40 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 116
ERROR - 2008-11-21 09:28:40 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$partner_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 117
ERROR - 2008-11-21 09:28:40 --> Query error: 
ERROR - 2008-11-21 09:29:12 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 117
ERROR - 2008-11-21 09:29:12 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 118
ERROR - 2008-11-21 09:29:12 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$partner_name /opt/Aptana Studio/php/likitomi/system/application/models/clamplift_model.php 119
ERROR - 2008-11-21 09:29:12 --> Query error: 
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:45 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:54 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:56 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 68
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$qty /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Notice  --> Undefined property:  stdClass::$slit /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:35:59 --> Severity: Warning  --> Division by zero /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 69
ERROR - 2008-11-21 10:38:51 --> Severity: 4096  --> Object of class Services_JSON_Error could not be converted to string /opt/Aptana Studio/php/likitomi/system/application/libraries/Services_JSON.php 442
ERROR - 2008-11-21 10:38:51 --> Severity: 4096  --> Object of class Services_JSON_Error could not be converted to string /opt/Aptana Studio/php/likitomi/system/application/libraries/Services_JSON.php 442
ERROR - 2008-11-21 10:38:51 --> Severity: Notice  --> Undefined variable: cnt /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 57
ERROR - 2008-11-21 10:39:14 --> Severity: Notice  --> Undefined variable: cnt /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftmanger.php 57
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: plandate /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 2
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:31:14 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:07 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:32:21 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:33:17 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:36:09 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 101
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:37 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:39:58 --> Severity: Notice  --> Undefined variable: timeStop /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 100
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:40:17 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 76
ERROR - 2008-11-21 11:41:40 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 77
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$D_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 79
ERROR - 2008-11-21 11:47:46 --> Severity: Notice  --> Undefined property:  stdClass::$PC_remarks /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clampliftstatus.php 80
ERROR - 2008-11-21 13:22:05 --> Query error: 
ERROR - 2008-11-21 13:30:22 --> 404 Page Not Found --> clampliftdriver/1
ERROR - 2008-11-21 13:30:37 --> 404 Page Not Found --> clampliftdriver/1
ERROR - 2008-11-21 13:40:10 --> Severity: Notice  --> Undefined variable: heading /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/clamplifthome.php 5
ERROR - 2008-11-21 13:45:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 2
ERROR - 2008-11-21 13:45:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 3
ERROR - 2008-11-21 13:45:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 4
ERROR - 2008-11-21 13:45:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 5
ERROR - 2008-11-21 13:45:40 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 6
ERROR - 2008-11-21 13:45:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 2
ERROR - 2008-11-21 13:45:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 3
ERROR - 2008-11-21 13:45:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 4
ERROR - 2008-11-21 13:45:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 5
ERROR - 2008-11-21 13:45:41 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 6
ERROR - 2008-11-21 13:45:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 2
ERROR - 2008-11-21 13:45:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 3
ERROR - 2008-11-21 13:45:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 4
ERROR - 2008-11-21 13:45:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 5
ERROR - 2008-11-21 13:45:57 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/clampliftdriver.php:42) /opt/Aptana Studio/php/likitomi/system/application/views/templateClamplift.php 6
ERROR - 2008-11-21 13:52:46 --> Query error: 
ERROR - 2008-11-21 13:53:58 --> Query error: 
ERROR - 2008-11-21 14:43:31 --> Query error: 
ERROR - 2008-11-21 17:56:11 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 71
ERROR - 2008-11-21 17:56:11 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 71
ERROR - 2008-11-21 17:56:11 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 71
ERROR - 2008-11-21 17:56:11 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 71
ERROR - 2008-11-21 17:56:11 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 71
ERROR - 2008-11-21 17:56:11 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 71
ERROR - 2008-11-21 17:56:11 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 71
ERROR - 2008-11-21 17:56:55 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 74
ERROR - 2008-11-21 17:56:55 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 74
ERROR - 2008-11-21 17:56:55 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 74
ERROR - 2008-11-21 17:56:55 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 74
ERROR - 2008-11-21 17:56:55 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 74
ERROR - 2008-11-21 17:56:55 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 74
ERROR - 2008-11-21 17:56:55 --> Severity: Notice  --> Use of undefined constant MAX - assumed 'MAX' /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 74
ERROR - 2008-11-21 18:14:36 --> Severity: Notice  --> Undefined variable: j /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 86
ERROR - 2008-11-21 18:14:36 --> Severity: Notice  --> Undefined variable: j /opt/Aptana Studio/php/likitomi/system/application/views/clamplift/vehicle/track.php 86
