<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:00:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:03:20 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:20:06 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:20:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:20:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:25:37 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:27:42 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:28:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:06 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:34:33 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:35:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:36:17 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:38:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:52:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:52:54 --> Query error: 
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:54:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-11 15:57:59 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
