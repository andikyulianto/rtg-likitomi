<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-09 10:59:10 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 10:59:10 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 10:59:10 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 11:24:20 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:24:20 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:24:20 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 11:25:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:25:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:25:12 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 11:26:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:26:01 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:26:01 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 11:26:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:26:07 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:26:07 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 11:26:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:26:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 11:26:26 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:47:11 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:47:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:47:12 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:48:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:15 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:15 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:48:18 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:18 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:48:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:26 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:48:34 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:34 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:48:41 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:41 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:48:41 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:49:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:49:14 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:49:14 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 13:49:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:49:30 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 54
ERROR - 2008-09-09 13:49:30 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/planning/reportplanning.php 55
ERROR - 2008-09-09 14:52:40 --> Severity: Notice  --> Undefined variable: partner_id /opt/Aptana Studio/php/likitomi/system/application/controllers/partners.php 132
ERROR - 2008-09-09 14:52:57 --> Severity: Notice  --> Undefined variable: partner_id /opt/Aptana Studio/php/likitomi/system/application/controllers/partners.php 132
ERROR - 2008-09-09 15:12:02 --> Severity: Notice  --> Undefined variable: tblppid /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 152
ERROR - 2008-09-09 15:12:02 --> Severity: Notice  --> Undefined variable: partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 154
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 6
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 10
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 13
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 14
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 23
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 27
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 31
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 44
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 48
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:12:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 6
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 10
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 13
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 14
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 23
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 27
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 31
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 44
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 48
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:12:25 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:12:38 --> Severity: Notice  --> Undefined variable: tblppid /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 152
ERROR - 2008-09-09 15:12:38 --> Severity: Notice  --> Undefined variable: partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 154
ERROR - 2008-09-09 15:15:10 --> Severity: Notice  --> Undefined variable: tblppid /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 152
ERROR - 2008-09-09 15:15:10 --> Severity: Notice  --> Undefined variable: partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 154
ERROR - 2008-09-09 15:25:07 --> Severity: Notice  --> Undefined property:  stdClass::$partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 97
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 6
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 10
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 13
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 14
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 23
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 27
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 31
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 44
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 48
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:25:17 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:25:30 --> Severity: Notice  --> Undefined property:  stdClass::$partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 97
ERROR - 2008-09-09 15:25:53 --> Severity: Notice  --> Undefined property:  stdClass::$partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 97
ERROR - 2008-09-09 15:30:06 --> Severity: Notice  --> Undefined property:  stdClass::$partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 97
ERROR - 2008-09-09 15:33:15 --> Severity: Notice  --> Undefined property:  stdClass::$partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 97
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 6
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 10
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 13
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 14
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 23
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 27
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 31
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 44
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 48
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:35:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 6
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 10
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 13
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 14
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 23
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 27
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 31
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 40
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 44
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 48
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 78
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:35:55 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 82
ERROR - 2008-09-09 15:39:05 --> Severity: Notice  --> Undefined property:  stdClass::$partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 97
ERROR - 2008-09-09 15:56:16 --> Severity: Notice  --> Undefined property:  stdClass::$partner_id /opt/Aptana Studio/php/likitomi/system/application/views/papers/paperdetail.php 97
ERROR - 2008-09-09 16:09:37 --> Query error: 
ERROR - 2008-09-09 16:09:46 --> Query error: 
ERROR - 2008-09-09 16:10:48 --> Query error: 
ERROR - 2008-09-09 16:28:24 --> Query error: 
