<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-12-20 09:47:24 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\warehouse.php 92
ERROR - 2008-12-20 09:47:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\warehouse.php 92
ERROR - 2008-12-20 09:57:13 --> 404 Page Not Found --> users/2
ERROR - 2008-12-20 09:59:37 --> 404 Page Not Found --> users/2
ERROR - 2008-12-20 09:59:41 --> 404 Page Not Found --> users/4
ERROR - 2008-12-20 10:02:15 --> 404 Page Not Found --> users/2
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 11:23:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 11:58:34 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:05:00 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:08:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:10:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:12:56 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:13:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:13:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\planning.php 91
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:14:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:19:26 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 12:22:13 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:31:16 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:01 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 76
ERROR - 2008-12-20 13:32:30 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\controllers\clampliftmanger.php 77
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 13:32:45 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 14:36:41 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\likitomi\system\application\controllers\planning.php 145
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:51:58 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:03 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:03 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:03 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:03 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:03 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:03 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:12 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:12 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:12 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:12 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:12 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:12 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:24 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 14:52:25 --> Severity: Notice  --> Undefined variable: code C:\wamp\www\likitomi\system\application\views\papers\paperlist.php 17
ERROR - 2008-12-20 15:30:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:30:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:30:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:30:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:31:57 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:32:23 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:32:23 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:32:23 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:32:23 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:33:19 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:33:19 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:33:19 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:33:19 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:33:56 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:33:56 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:33:56 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:34:32 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:34:32 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:34:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 15:34:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 15:34:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2008-12-20 15:34:48 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2008-12-20 15:34:53 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:34:53 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:34:53 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2008-12-20 15:34:53 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2008-12-20 15:34:59 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\deliverydaily.php 33
ERROR - 2008-12-20 15:34:59 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\deliverydaily.php 33
ERROR - 2008-12-20 15:51:22 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:51:22 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:51:55 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:54:59 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2008-12-20 15:56:50 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
