<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-01 01:08:21 --> Severity: Notice  --> Undefined variable: product_id /opt/Aptana Studio/php/likitomi/system/application/controllers/salesorder.php 224
ERROR - 2008-09-01 01:08:34 --> Severity: Notice  --> Undefined variable: product_id /opt/Aptana Studio/php/likitomi/system/application/controllers/salesorder.php 224
ERROR - 2008-09-01 01:09:50 --> Severity: Notice  --> Undefined variable: product_id /opt/Aptana Studio/php/likitomi/system/application/controllers/salesorder.php 224
ERROR - 2008-09-01 17:10:11 --> Severity: Notice  --> Use of undefined constant i - assumed 'i' /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 24
ERROR - 2008-09-01 17:10:11 --> Severity: Notice  --> Undefined index:  i /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 24
ERROR - 2008-09-01 17:10:26 --> Severity: Notice  --> Use of undefined constant i - assumed 'i' /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 24
ERROR - 2008-09-01 17:10:26 --> Severity: Notice  --> Undefined index:  i /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 24
