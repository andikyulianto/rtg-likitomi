<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-24 12:53:57 --> 404 Page Not Found --> home
ERROR - 2008-09-24 16:14:54 --> Query error: 
ERROR - 2008-09-24 17:51:15 --> Query error: 
