<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-24 09:36:53 --> Severity: Notice  --> Undefined variable: productCodes /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 363
ERROR - 2008-08-24 09:37:27 --> Severity: Notice  --> Undefined offset:  3 /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 365
ERROR - 2008-08-24 11:23:44 --> Severity: Notice  --> Undefined variable: cnt /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 25
ERROR - 2008-08-24 11:23:44 --> Severity: Notice  --> Undefined variable: prod /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 25
ERROR - 2008-08-24 11:23:44 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 25
ERROR - 2008-08-24 11:23:44 --> Severity: Notice  --> Undefined variable: prod /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 25
ERROR - 2008-08-24 11:23:44 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 25
ERROR - 2008-08-24 11:23:44 --> Severity: Notice  --> Undefined variable: cnt /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 26
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$sales_order_date /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 6
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$sales_order_id /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 8
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_1 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_1 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_2 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 32
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_2 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 32
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_3 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 41
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_3 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 41
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_4 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 50
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_4 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 50
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$delivery_at /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 66
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$purchase_order_no /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 78
ERROR - 2008-08-24 14:39:37 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$remarks /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 80
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 6
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 8
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 32
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 32
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 41
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 41
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 50
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 50
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 66
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 78
ERROR - 2008-08-24 14:41:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 80
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$sales_order_date /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 6
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$sales_order_id /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 8
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_1 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_1 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_2 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 32
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_2 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 32
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_3 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 41
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_3 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 41
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_4 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 50
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_4 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 50
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$delivery_at /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 66
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$purchase_order_no /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 78
ERROR - 2008-08-24 14:47:25 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$remarks /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 80
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$sales_order_date /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 21
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$sales_order_id /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_1 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 38
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_1 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 38
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_2 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 47
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_2 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 47
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_3 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 56
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_3 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 56
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_4 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 65
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$product_code_4 /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 65
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$delivery_at /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 81
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$purchase_order_no /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 93
ERROR - 2008-08-24 15:19:39 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$remarks /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 95
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 21
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 23
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 38
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 38
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 47
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 47
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 56
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 56
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 65
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 65
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 81
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 93
ERROR - 2008-08-24 15:20:12 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorderdetail.php 95
ERROR - 2008-08-24 23:18:04 --> Severity: Notice  --> Undefined variable: tblDelivery /opt/Aptana Studio/php/likitomi/system/application/models/products_model.php 274
ERROR - 2008-08-24 23:18:25 --> Query error: 
