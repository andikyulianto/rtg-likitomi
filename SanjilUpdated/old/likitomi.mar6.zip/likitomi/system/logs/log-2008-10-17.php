<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-17 10:51:28 --> Query error: 
ERROR - 2008-10-17 10:53:04 --> Query error: 
ERROR - 2008-10-17 10:55:20 --> Query error: 
ERROR - 2008-10-17 10:56:50 --> 404 Page Not Found --> papers/go
ERROR - 2008-10-17 10:57:55 --> 404 Page Not Found --> papers/go
ERROR - 2008-10-17 10:58:04 --> Query error: 
