<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-11-06 09:52:12 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 33
ERROR - 2008-11-06 09:58:35 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 36
ERROR - 2008-11-06 09:58:36 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 36
ERROR - 2008-11-06 10:17:15 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 37
ERROR - 2008-11-06 11:01:01 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 9
ERROR - 2008-11-06 11:07:28 --> Severity: Notice  --> Undefined property:  stdClass::$unit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 41
ERROR - 2008-11-06 11:07:28 --> Severity: Notice  --> Undefined property:  stdClass::$rfid_tag /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 45
ERROR - 2008-11-06 11:07:28 --> Severity: Notice  --> Undefined property:  stdClass::$unit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 41
ERROR - 2008-11-06 11:07:28 --> Severity: Notice  --> Undefined property:  stdClass::$rfid_tag /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 45
ERROR - 2008-11-06 11:07:44 --> Severity: Notice  --> Undefined property:  stdClass::$rfid_tag /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 45
ERROR - 2008-11-06 11:07:44 --> Severity: Notice  --> Undefined property:  stdClass::$rfid_tag /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 45
ERROR - 2008-11-06 11:07:44 --> Severity: Notice  --> Undefined property:  stdClass::$rfid_tag /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 45
ERROR - 2008-11-06 11:39:59 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 97
ERROR - 2008-11-06 11:41:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 97
ERROR - 2008-11-06 11:45:51 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 97
ERROR - 2008-11-06 11:47:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:47:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:48:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:48:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:48:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:48:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:48:35 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:48:35 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:42 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:49 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:51 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:53 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:56 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:58 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:49:59 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:50:54 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 98
ERROR - 2008-11-06 11:51:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 11:51:28 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 11:52:03 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 11:52:03 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 11:52:04 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 11:53:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 11:53:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 11:53:29 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 12:17:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 12:17:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 12:22:14 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 12:22:16 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 12:22:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 12:22:19 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 99
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 64
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 65
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 66
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 67
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 68
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 69
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 70
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 71
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 72
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 73
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 74
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 75
ERROR - 2008-11-06 15:04:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 76
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 64
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 65
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 66
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 67
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 68
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 69
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 70
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 71
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 72
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 73
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 74
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 75
ERROR - 2008-11-06 15:05:48 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 76
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 64
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 64
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 65
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 65
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 66
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 66
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 67
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 67
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 68
ERROR - 2008-11-06 15:46:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 68
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 64
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 64
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 65
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 65
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 66
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 66
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 67
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 67
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Undefined offset:  0 /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 68
ERROR - 2008-11-06 15:46:34 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 68
ERROR - 2008-11-06 16:53:52 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouse.php 179
ERROR - 2008-11-06 16:54:51 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouse.php 179
ERROR - 2008-11-06 16:55:02 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouse.php 179
ERROR - 2008-11-06 16:55:51 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouse.php 179
ERROR - 2008-11-06 16:56:10 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouse.php 179
