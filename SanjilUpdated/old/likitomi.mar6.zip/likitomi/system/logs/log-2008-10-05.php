<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-05 13:06:19 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-05 13:06:19 --> Unable to connect to the database
