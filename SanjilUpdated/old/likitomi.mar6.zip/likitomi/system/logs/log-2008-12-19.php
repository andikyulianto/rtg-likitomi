<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-12-19 22:14:27 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:14:27 --> Unable to connect to the database
ERROR - 2008-12-19 22:14:30 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:14:30 --> Unable to connect to the database
ERROR - 2008-12-19 22:14:32 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:14:32 --> Unable to connect to the database
ERROR - 2008-12-19 22:14:42 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:14:42 --> Unable to connect to the database
ERROR - 2008-12-19 22:14:44 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:14:44 --> Unable to connect to the database
ERROR - 2008-12-19 22:15:14 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:15:14 --> Unable to connect to the database
ERROR - 2008-12-19 22:15:15 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:15:15 --> Unable to connect to the database
ERROR - 2008-12-19 22:16:04 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:16:04 --> Unable to connect to the database
ERROR - 2008-12-19 22:16:06 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:16:06 --> Unable to connect to the database
ERROR - 2008-12-19 22:16:27 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on '203.159.107.10' (4) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:16:27 --> Unable to connect to the database
ERROR - 2008-12-19 22:16:52 --> Unable to select database: likitomidb
ERROR - 2008-12-19 22:16:54 --> Unable to select database: likitomidb
ERROR - 2008-12-19 22:17:02 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'likitomidb'@'localhost' (using password: YES) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:17:02 --> Unable to connect to the database
ERROR - 2008-12-19 22:17:19 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:17:19 --> Unable to connect to the database
ERROR - 2008-12-19 22:17:20 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:17:20 --> Unable to connect to the database
ERROR - 2008-12-19 22:17:27 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Unknown MySQL server host 'localhost1' (1) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:17:27 --> Unable to connect to the database
ERROR - 2008-12-19 22:17:36 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:17:36 --> Unable to connect to the database
ERROR - 2008-12-19 22:17:37 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Access denied for user 'root'@'localhost' (using password: NO) /opt/aptana/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-12-19 22:17:37 --> Unable to connect to the database
ERROR - 2008-12-19 22:27:12 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '192.168.1.100' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-12-19 22:27:28 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '192.168.1.100' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-12-19 22:27:43 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '192.168.1.100' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-12-19 22:41:43 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '203.159.1.123' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-12-19 22:42:06 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '203.159.1.123' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-12-19 22:42:10 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '203.159.1.123' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-12-19 22:42:19 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '203.159.1.123' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
ERROR - 2008-12-19 22:42:53 --> Severity: Warning  --> mysql_connect() [<a href='function.mysql-connect'>function.mysql-connect</a>]: Can't connect to MySQL server on '203.159.1.123' (4) /opt/aptana/likitomi/system/application/views/clamplift/syncclampliftdata.php 4
