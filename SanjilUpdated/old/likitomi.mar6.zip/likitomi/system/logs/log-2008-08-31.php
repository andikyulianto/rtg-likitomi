<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-31 09:14:58 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:14:58 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:14:59 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:14:59 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:14:59 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:14:59 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:14:59 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:15:00 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:15:00 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 09:15:00 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 13:22:56 --> Severity: Notice  --> Undefined variable: leftmenu /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/salesorder.php 42
ERROR - 2008-08-31 14:14:57 --> Unable to select database: likitomi_v5
ERROR - 2008-08-31 14:15:55 --> Unable to select database: likitomi_v5
ERROR - 2008-08-31 14:24:15 --> Unable to select database: likitomi_v5
ERROR - 2008-08-31 14:24:18 --> Unable to select database: likitomi_v5
ERROR - 2008-08-31 15:00:37 --> 404 Page Not Found --> products/reportCatalog
ERROR - 2008-08-31 15:08:10 --> 404 Page Not Found --> products/reportCatalog
ERROR - 2008-08-31 16:59:03 --> Query error: 
ERROR - 2008-08-31 17:06:10 --> 404 Page Not Found --> salesorder/loadSalesOrder
ERROR - 2008-08-31 17:41:01 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/createsalesorder.php 1
ERROR - 2008-08-31 17:41:01 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/createsalesorder.php 48
ERROR - 2008-08-31 17:41:01 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/createsalesorder.php 48
ERROR - 2008-08-31 17:41:01 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/createsalesorder.php 62
ERROR - 2008-08-31 17:41:01 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/createsalesorder.php 65
ERROR - 2008-08-31 17:41:01 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/salesorder/createsalesorder.php 68
ERROR - 2008-08-31 17:46:15 --> Severity: Notice  --> Undefined property:  SalesOrder::$Partners_model /opt/Aptana Studio/php/likitomi/system/application/controllers/salesorder.php 113
ERROR - 2008-08-31 19:19:31 --> 404 Page Not Found --> products/reportCatalog
ERROR - 2008-08-31 19:32:35 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 19:32:39 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 19:32:43 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 19:42:13 --> 404 Page Not Found --> welcome
ERROR - 2008-08-31 19:52:22 --> 404 Page Not Found --> welcome
