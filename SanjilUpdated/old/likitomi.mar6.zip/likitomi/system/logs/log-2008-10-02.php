<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-02 13:58:53 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'im.ait.ac.th' (65) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-02 13:58:53 --> Unable to connect to the database
ERROR - 2008-10-02 14:00:14 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-02 14:00:14 --> Unable to connect to the database
ERROR - 2008-10-02 14:00:17 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-02 14:00:17 --> Unable to connect to the database
ERROR - 2008-10-02 14:00:38 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-02 14:00:38 --> Unable to connect to the database
ERROR - 2008-10-02 14:00:40 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-02 14:00:40 --> Unable to connect to the database
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 4
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 6
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 7
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 8
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: partner_isdeleted /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 9
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
ERROR - 2008-10-02 14:40:40 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/productsaleshistory.php 12
