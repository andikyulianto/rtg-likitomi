<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-29 15:48:06 --> Severity: Notice  --> Undefined variable: i /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 118
ERROR - 2008-09-29 15:48:06 --> Severity: Notice  --> Undefined variable: delivery_ids /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 118
ERROR - 2008-09-29 15:48:06 --> Severity: Notice  --> Undefined variable: i /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 119
ERROR - 2008-09-29 15:48:06 --> Severity: Notice  --> Undefined variable: corrugator_dates /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 119
ERROR - 2008-09-29 15:48:06 --> Severity: Notice  --> Undefined variable: i /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 120
ERROR - 2008-09-29 15:48:06 --> Severity: Notice  --> Undefined variable: converter_dates /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 120
ERROR - 2008-09-29 15:48:06 --> Query error: 
ERROR - 2008-09-29 15:50:21 --> Severity: Notice  --> Undefined variable: delivery_id /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 118
ERROR - 2008-09-29 15:51:39 --> Severity: Notice  --> Undefined variable: corrugator_date /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 120
ERROR - 2008-09-29 15:51:48 --> Query error: 
ERROR - 2008-09-29 16:09:48 --> 404 Page Not Found --> Scaffolding unavailable
ERROR - 2008-09-29 16:09:51 --> 404 Page Not Found --> Scaffolding unavailable
ERROR - 2008-09-29 18:18:32 --> Query error: 
