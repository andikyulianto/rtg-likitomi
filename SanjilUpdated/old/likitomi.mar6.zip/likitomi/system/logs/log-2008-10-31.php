<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-31 15:10:25 --> Severity: Notice  --> Undefined offset:  1 /opt/Aptana Studio/php/likitomi/system/application/models/warehouse_model.php 75
ERROR - 2008-10-31 17:01:39 --> Severity: Notice  --> Undefined offset:  1 /opt/Aptana Studio/php/likitomi/system/application/models/warehouse_model.php 75
ERROR - 2008-10-31 17:01:39 --> Severity: Notice  --> Undefined offset:  1 /opt/Aptana Studio/php/likitomi/system/application/models/warehouse_model.php 87
