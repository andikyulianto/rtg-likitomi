<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-27 01:02:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-27 01:02:18 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-27 01:02:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-27 01:02:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-27 01:02:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 338
ERROR - 2008-08-27 01:02:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 2
ERROR - 2008-08-27 01:02:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 3
ERROR - 2008-08-27 01:02:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 4
ERROR - 2008-08-27 01:02:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 5
ERROR - 2008-08-27 01:02:26 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 6
ERROR - 2008-08-27 01:04:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-27 01:04:26 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-27 01:04:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 338
ERROR - 2008-08-27 01:04:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 2
ERROR - 2008-08-27 01:04:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 3
ERROR - 2008-08-27 01:04:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 4
ERROR - 2008-08-27 01:04:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 5
ERROR - 2008-08-27 01:04:28 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/libraries/Exceptions.php:164) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 6
ERROR - 2008-08-27 01:05:38 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-27 01:05:38 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-27 01:08:09 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 100
ERROR - 2008-08-27 01:08:09 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 101
ERROR - 2008-08-27 12:59:17 --> 404 Page Not Found --> welcome
ERROR - 2008-08-27 13:19:26 --> Severity: Notice  --> Undefined variable: salesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 54
ERROR - 2008-08-27 13:19:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:351) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 2
ERROR - 2008-08-27 13:19:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:351) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 3
ERROR - 2008-08-27 13:19:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:351) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 4
ERROR - 2008-08-27 13:19:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:351) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 5
ERROR - 2008-08-27 13:19:44 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:351) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 6
ERROR - 2008-08-27 13:19:44 --> Severity: Notice  --> Undefined variable: salesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 54
ERROR - 2008-08-27 13:20:29 --> Severity: Notice  --> Undefined variable: salesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 54
ERROR - 2008-08-27 13:21:20 --> Severity: Notice  --> Undefined variable: salesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 155
ERROR - 2008-08-27 13:21:20 --> Severity: Notice  --> Undefined variable: salesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 155
ERROR - 2008-08-27 13:21:49 --> Severity: Notice  --> Undefined variable: salesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 172
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 364
ERROR - 2008-08-27 13:28:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 2
ERROR - 2008-08-27 13:28:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 3
ERROR - 2008-08-27 13:28:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 4
ERROR - 2008-08-27 13:28:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 5
ERROR - 2008-08-27 13:28:52 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 6
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 53
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 53
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 54
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 66
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 67
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 67
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: productDetails /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:28:52 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 117
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 117
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 118
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 118
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 119
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 119
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 123
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 123
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 124
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 124
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 125
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 125
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 126
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 126
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 127
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 127
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 128
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 128
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 130
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 130
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 133
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 133
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 134
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 134
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 135
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 135
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 139
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 139
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 151
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 151
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 155
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 157
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 157
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: numSales /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 172
ERROR - 2008-08-27 13:28:52 --> Severity: Notice  --> Undefined variable: numDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 190
ERROR - 2008-08-27 13:29:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 2
ERROR - 2008-08-27 13:29:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 3
ERROR - 2008-08-27 13:29:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 4
ERROR - 2008-08-27 13:29:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 5
ERROR - 2008-08-27 13:29:06 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php:348) /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 6
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 53
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 53
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 66
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 67
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 67
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: productDetails /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:06 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 117
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 117
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 118
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 118
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 119
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 119
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 123
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 123
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 124
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 124
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 125
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 125
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 126
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 126
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 127
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 127
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 128
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 128
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 130
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 130
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 133
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 133
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 134
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 134
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 135
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 135
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 139
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 139
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 151
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 151
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 157
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 157
ERROR - 2008-08-27 13:29:06 --> Severity: Notice  --> Undefined variable: numDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 190
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 53
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 53
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 66
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 67
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 67
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: productDetails /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:23 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 117
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 117
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 118
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 118
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 119
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 119
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 123
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 123
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 124
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 124
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 125
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 125
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 126
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 126
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 127
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 127
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 128
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 128
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 130
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 130
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 133
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 133
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 134
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 134
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 135
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 135
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 139
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 139
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 151
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 151
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 156
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 157
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 157
ERROR - 2008-08-27 13:29:23 --> Severity: Notice  --> Undefined variable: numDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 190
ERROR - 2008-08-27 13:29:30 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 66
ERROR - 2008-08-27 13:29:30 --> Severity: Notice  --> Undefined variable: productDetails /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:30 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:30 --> Severity: Notice  --> Undefined variable: numDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 190
ERROR - 2008-08-27 13:29:36 --> Severity: Notice  --> Undefined variable: customer_name /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 66
ERROR - 2008-08-27 13:29:36 --> Severity: Notice  --> Undefined variable: productDetails /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:36 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 88
ERROR - 2008-08-27 13:29:36 --> Severity: Notice  --> Undefined variable: numDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 190
ERROR - 2008-08-27 13:29:42 --> Severity: Notice  --> Undefined variable: numDelivery /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 190
ERROR - 2008-08-27 13:29:51 --> Query error: 
ERROR - 2008-08-27 13:31:54 --> Severity: Notice  --> Undefined property:  stdClass::$amount /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 198
ERROR - 2008-08-27 13:31:54 --> Severity: Notice  --> Undefined property:  stdClass::$amount /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 198
ERROR - 2008-08-27 13:31:54 --> Severity: Notice  --> Undefined property:  stdClass::$amount /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 198
ERROR - 2008-08-27 13:31:54 --> Severity: Notice  --> Undefined property:  stdClass::$amount /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 198
ERROR - 2008-08-27 14:06:18 --> Severity: Notice  --> Undefined property:  stdClass::$product_1 /opt/Aptana Studio/php/likitomi/system/application/views/products/report.php 166
ERROR - 2008-08-27 16:05:15 --> Severity: Notice  --> Undefined variable: sales_order_id /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 402
ERROR - 2008-08-27 16:05:15 --> Severity: Notice  --> Undefined variable: sales_order_id /opt/Aptana Studio/php/likitomi/system/application/controllers/products.php 409
ERROR - 2008-08-27 16:05:40 --> Severity: Notice  --> Use of undefined constant edit - assumed 'edit' /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 1
ERROR - 2008-08-27 16:05:42 --> Severity: Notice  --> Use of undefined constant edit - assumed 'edit' /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 1
ERROR - 2008-08-27 16:06:15 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 3
ERROR - 2008-08-27 16:06:15 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 3
ERROR - 2008-08-27 16:06:40 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 3
ERROR - 2008-08-27 16:06:40 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 3
ERROR - 2008-08-27 16:06:56 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 3
ERROR - 2008-08-27 16:06:56 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesorder.php 3
ERROR - 2008-08-27 16:07:28 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 1
ERROR - 2008-08-27 16:07:28 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 43
ERROR - 2008-08-27 16:07:28 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 43
ERROR - 2008-08-27 16:07:28 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 57
ERROR - 2008-08-27 16:07:28 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 60
ERROR - 2008-08-27 16:07:28 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 63
ERROR - 2008-08-27 16:07:47 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 1
ERROR - 2008-08-27 16:07:47 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 43
ERROR - 2008-08-27 16:07:47 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 43
ERROR - 2008-08-27 16:07:47 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 57
ERROR - 2008-08-27 16:07:47 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 60
ERROR - 2008-08-27 16:07:47 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 63
ERROR - 2008-08-27 16:09:16 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 1
ERROR - 2008-08-27 16:09:16 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 43
ERROR - 2008-08-27 16:09:16 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 43
ERROR - 2008-08-27 16:09:16 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 57
ERROR - 2008-08-27 16:09:16 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 60
ERROR - 2008-08-27 16:09:16 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 63
ERROR - 2008-08-27 16:09:49 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 1
ERROR - 2008-08-27 16:09:49 --> Severity: Notice  --> Undefined variable: action /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 2
ERROR - 2008-08-27 16:09:49 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:09:49 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:09:49 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 58
ERROR - 2008-08-27 16:09:49 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 61
ERROR - 2008-08-27 16:09:49 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 64
ERROR - 2008-08-27 16:10:14 --> Severity: Notice  --> Undefined property:  CI_DB_mysql_result::$sales_order_id /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 22
ERROR - 2008-08-27 16:10:14 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:10:14 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:10:14 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 58
ERROR - 2008-08-27 16:10:14 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 61
ERROR - 2008-08-27 16:10:14 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 64
ERROR - 2008-08-27 16:11:42 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:11:42 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:11:42 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 58
ERROR - 2008-08-27 16:11:42 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 61
ERROR - 2008-08-27 16:11:42 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 64
ERROR - 2008-08-27 16:13:48 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:13:48 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:13:48 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 58
ERROR - 2008-08-27 16:13:48 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 61
ERROR - 2008-08-27 16:13:48 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 64
ERROR - 2008-08-27 16:14:38 --> Severity: Notice  --> Undefined variable: resultProducts /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:14:38 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 44
ERROR - 2008-08-27 16:14:38 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 58
ERROR - 2008-08-27 16:14:38 --> Severity: Notice  --> Undefined variable: billing_address /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 61
ERROR - 2008-08-27 16:14:38 --> Severity: Notice  --> Undefined variable: deliveryAddresses /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 64
ERROR - 2008-08-27 16:23:36 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 49
ERROR - 2008-08-27 16:23:36 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 49
ERROR - 2008-08-27 16:23:37 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 49
ERROR - 2008-08-27 16:23:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 49
ERROR - 2008-08-27 16:23:37 --> Severity: Notice  --> Undefined variable: resultSalesOrder /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 49
ERROR - 2008-08-27 16:23:37 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/views/products/salesordercontent.php 49
