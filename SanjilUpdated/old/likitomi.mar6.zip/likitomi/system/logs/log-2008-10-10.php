<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-10 10:35:19 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 11:28:37 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 11:28:42 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 12:48:33 --> 404 Page Not Found --> auth/login
ERROR - 2008-10-10 12:49:59 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 13:04:25 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 13:04:28 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 14:42:28 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 14:44:21 --> Severity: Warning  --> unlink(tmp/.svn) [<a href='function.unlink'>function.unlink</a>]: Operation not permitted /opt/Aptana Studio/php/likitomi/system/application/libraries/Freakauth_light.php 1034
ERROR - 2008-10-10 15:29:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:31) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 2
ERROR - 2008-10-10 15:29:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:31) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 3
ERROR - 2008-10-10 15:29:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:31) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 4
ERROR - 2008-10-10 15:29:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:31) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 5
ERROR - 2008-10-10 15:29:19 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:31) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 6
ERROR - 2008-10-10 15:30:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:37) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 2
ERROR - 2008-10-10 15:30:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:37) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 3
ERROR - 2008-10-10 15:30:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:37) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 4
ERROR - 2008-10-10 15:30:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:37) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 5
ERROR - 2008-10-10 15:30:17 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/language/english/papers_lang.php:37) /opt/Aptana Studio/php/likitomi/system/application/views/template.php 6
ERROR - 2008-10-10 16:33:33 --> Severity: Notice  --> Undefined property:  Papers::$session /opt/Aptana Studio/php/likitomi/system/application/controllers/papers.php 8
ERROR - 2008-10-10 16:34:08 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:36:56 --> Severity: Notice  --> Undefined property:  Home::$session /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 24
ERROR - 2008-10-10 16:37:06 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:37:20 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:38:00 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:38:24 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:39:20 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:40:27 --> Severity: Notice  --> Undefined property:  Papers::$session /opt/Aptana Studio/php/likitomi/system/application/controllers/papers.php 9
ERROR - 2008-10-10 16:40:42 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:54:02 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 16:54:20 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 17:00:07 --> Severity: Notice  --> Undefined property:  Home::$session /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 19
ERROR - 2008-10-10 17:00:13 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 17:00:22 --> The session cookie data did not contain a valid array. This could be a possible hacking attempt.
ERROR - 2008-10-10 17:09:23 --> Severity: Notice  --> Undefined property:  Home::$CI /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 23
ERROR - 2008-10-10 17:09:23 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 23
ERROR - 2008-10-10 17:20:27 --> Severity: Notice  --> Undefined property:  Home::$CI /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 23
ERROR - 2008-10-10 17:20:27 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 23
ERROR - 2008-10-10 17:21:57 --> Severity: Notice  --> Undefined property:  Home::$CI /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 23
ERROR - 2008-10-10 17:21:57 --> Severity: Notice  --> Trying to get property of non-object /opt/Aptana Studio/php/likitomi/system/application/controllers/home.php 23
