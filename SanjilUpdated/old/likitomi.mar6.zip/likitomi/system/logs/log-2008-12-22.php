<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-12-22 11:14:04 --> 404 Page Not Found --> users/2
ERROR - 2008-12-22 11:14:09 --> 404 Page Not Found --> users/4
