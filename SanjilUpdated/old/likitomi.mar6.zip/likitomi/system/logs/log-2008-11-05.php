<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-11-05 13:52:44 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 13:54:38 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 13:56:02 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 13:57:54 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 14:00:11 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 14:00:13 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 14:02:28 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 14:04:54 --> Severity: Notice  --> Undefined variable: data /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 47
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:28:41 --> Severity: Notice  --> Undefined property:  stdClass::$invoice_no /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehouselist.php 22
ERROR - 2008-11-05 14:29:30 --> Query error: 
ERROR - 2008-11-05 14:39:00 --> Severity: Notice  --> Use of undefined constant invoice_no - assumed 'invoice_no' /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 86
ERROR - 2008-11-05 14:40:19 --> Severity: Notice  --> Use of undefined constant invoice_no - assumed 'invoice_no' /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 87
ERROR - 2008-11-05 14:40:25 --> Severity: Notice  --> Use of undefined constant invoice_no - assumed 'invoice_no' /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 87
ERROR - 2008-11-05 14:43:48 --> Severity: Notice  --> Use of undefined constant invoice_no - assumed 'invoice_no' /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 87
ERROR - 2008-11-05 14:46:32 --> Severity: Notice  --> Use of undefined constant invoice_no - assumed 'invoice_no' /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 87
ERROR - 2008-11-05 14:46:41 --> Severity: Notice  --> Use of undefined constant invoice_no - assumed 'invoice_no' /opt/Aptana Studio/php/likitomi/system/application/controllers/warehouse.php 87
ERROR - 2008-11-05 14:49:29 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 32
ERROR - 2008-11-05 16:46:48 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 32
ERROR - 2008-11-05 16:47:00 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 32
ERROR - 2008-11-05 16:50:25 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 32
ERROR - 2008-11-05 16:51:50 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 30
ERROR - 2008-11-05 16:51:52 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 30
ERROR - 2008-11-05 16:51:58 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 30
ERROR - 2008-11-05 16:52:55 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 30
ERROR - 2008-11-05 16:53:13 --> Severity: Notice  --> Undefined variable: limit /opt/Aptana Studio/php/likitomi/system/application/views/warehouse/warehousedetail.php 30
