<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-10-11 11:10:56 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to MySQL server on 'im.ait.ac.th' (4) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-10-11 11:10:56 --> Unable to connect to the database
ERROR - 2008-10-11 11:24:46 --> Severity: Warning  --> Cannot modify header information - headers already sent by (output started at /opt/Aptana Studio/php/likitomi/system/application/controllers/auth.php:65) /opt/Aptana Studio/php/likitomi/system/application/libraries/Db_session.php 248
