<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-09-07 10:40:37 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: Can't connect to local MySQL server through socket '/Applications/MAMP/tmp/mysql/mysql.sock' (2) /opt/Aptana Studio/php/likitomi/system/database/drivers/mysql/mysql_driver.php 69
ERROR - 2008-09-07 10:40:37 --> Unable to connect to the database
ERROR - 2008-09-07 23:29:44 --> Severity: Notice  --> Undefined variable: i /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 47
ERROR - 2008-09-07 23:29:44 --> Severity: Notice  --> Undefined index:   /opt/Aptana Studio/php/likitomi/system/application/models/planning_model.php 47
