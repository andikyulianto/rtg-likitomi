<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2008-08-28 13:16:35 --> Query error: 
ERROR - 2008-08-28 13:51:14 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 13:51:16 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 13:51:27 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 13:51:46 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 13:52:05 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 13:52:36 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 13:52:38 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 13:53:07 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 14:07:38 --> 404 Page Not Found --> sales
ERROR - 2008-08-28 14:27:05 --> 404 Page Not Found --> plan
ERROR - 2008-08-28 17:43:26 --> 404 Page Not Found --> welcome
ERROR - 2008-08-28 17:44:03 --> Query error: 
ERROR - 2008-08-28 17:46:07 --> Query error: 
ERROR - 2008-08-28 23:16:12 --> Severity: Warning  --> Invalid argument supplied for foreach() /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 80
ERROR - 2008-08-28 23:22:24 --> Severity: Notice  --> Undefined offset:  1 /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 83
ERROR - 2008-08-28 23:22:24 --> Severity: Notice  --> Undefined offset:  2 /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 83
ERROR - 2008-08-28 23:22:24 --> Severity: Notice  --> Undefined offset:  4 /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 83
ERROR - 2008-08-28 23:22:24 --> Severity: Notice  --> Undefined offset:  5 /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 83
ERROR - 2008-08-28 23:22:24 --> Severity: Notice  --> Undefined offset:  6 /opt/Aptana Studio/php/likitomi/system/application/views/planning/planning.php 83
