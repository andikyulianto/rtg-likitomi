<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 17:15:48 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 17:20:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 17:25:01 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 17:36:14 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 18:47:30 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 18:50:14 --> Query error: 
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 18:54:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 19:04:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 19:04:23 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 19:09:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-10 19:11:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 104
ERROR - 2009-02-10 19:11:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 105
ERROR - 2009-02-10 19:11:18 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 106
ERROR - 2009-02-10 19:11:44 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\salesorder.php 91
ERROR - 2009-02-10 19:12:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 104
ERROR - 2009-02-10 19:12:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 105
ERROR - 2009-02-10 19:12:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\controllers\products.php 106
