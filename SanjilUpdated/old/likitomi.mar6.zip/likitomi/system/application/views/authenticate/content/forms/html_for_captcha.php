<span class="note">
    <img src="<?=base_url().$this->config->item('FAL_captcha_image_path').$this->config->item('FAL_captcha_image')?>" alt="captcha img" />
</span>
