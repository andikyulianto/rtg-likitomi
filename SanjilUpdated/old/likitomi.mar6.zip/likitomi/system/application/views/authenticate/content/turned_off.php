<html>
	<head>
		<title><?=$website_name?></title>
	</head>
	<body>
		<br /><br /><br />
		<h1 style="text-align:center;"><?=$message?></h1>
	</body>
</html>
