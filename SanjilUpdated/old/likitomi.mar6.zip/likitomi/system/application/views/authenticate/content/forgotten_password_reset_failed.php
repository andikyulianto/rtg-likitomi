<?=$this->lang->line('FAL_forgotten_password_reset_failed_message');?>
<br />
<br />
<?=anchor($this->config->item('FAL_forgottenPassword_uri'), $this->lang->line('FAL_continue_label'))?>