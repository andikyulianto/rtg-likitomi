<?php
$this->load->view($this->config->item('FAL_template_dir').'template/header');
$this->load->view($this->config->item('FAL_template_dir').'template/content');
$this->load->view($this->config->item('FAL_template_dir').'template/footer');
?> 
