<?=$welcome?> <?=getUserName()?> / <?=anchor($logout_uri, $logout_label, $logout_attributes)?>
