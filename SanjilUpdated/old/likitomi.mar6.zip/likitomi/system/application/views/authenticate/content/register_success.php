<?=$this->lang->line('FAL_register_success_message');?>
<br />
<br />
<?=anchor($this->config->item('FAL_register_continue_action'), $this->lang->line('FAL_continue_label'))?>
