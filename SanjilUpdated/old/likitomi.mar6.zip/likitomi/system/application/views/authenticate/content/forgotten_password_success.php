<?=$this->lang->line('FAL_forgotten_password_success_message');?>
<br />
<br />
<?=anchor($this->config->item('FAL_forgotten_password_continue_action'), $this->lang->line('FAL_continue_label'))?>
