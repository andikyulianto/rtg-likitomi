<!--START FOOTER-->
<div id="footer">
    <p><a href="#top">Top of Page</a></p>
</div>
<!--END FOOTER-->
</body>
</html>
