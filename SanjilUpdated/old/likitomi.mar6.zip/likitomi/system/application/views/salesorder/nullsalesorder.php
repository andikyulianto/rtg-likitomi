<table width='100%'>
	<tr>
		<td width=140 class='tabunselect' onclick='createSalesOrderPage();'>1. Create Sales Order</td>
		<td width=6>&nbsp;</td>
		<td width=140 class='tabselect'> 2. Review Sales Order</td>
		<td align='right'></td>
	</tr>
	<tr>
		<td height='5' class='tbltabslinecenter'></td>
		<td class='tbltabslinecenter'></td>
		<td class='tbltabslineselect'></td>
		<td class='tbltabslineright'></td>
	</tr>
</table>
<br/>

<div id='boxcontainer'>
<center>
	NO RECORDS
</center>
</div>