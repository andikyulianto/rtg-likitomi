<?php

//Modules
$lang['partners'] 		= "Partners";
$lang['papers'] 		= "Papers";
$lang['products'] 		= "Products";
$lang['salesorder'] 	= "Sales Order";
$lang['planning'] 		= "Planning";
$lang['reportplanning'] = "Report Planning";
$lang['warehouse'] 		= "Warehouse";
$lang['translation'] 	= "Translation";

//Buttons
$lang['edit'] 		= "Edit";
$lang['update'] 	= "Update";
$lang['cancel'] 	= "Cancel";
$lang['save'] 		= "Save";
$lang['archive'] 	= "Archive";
$lang['add'] 		= "Add";


?>
