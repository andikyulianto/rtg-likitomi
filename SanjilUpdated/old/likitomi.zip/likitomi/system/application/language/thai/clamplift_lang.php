<?php

$lang['title']			= ระบบการทำงานรถหนีบกระดาษ;
$lang['Now']			= ขณะนี้;
$lang['Morning']		= เช้า;
$lang['Afternoon']		= บ่าย;
$lang['Evening']		= เย็น;
$lang['Late_Night']		= ค่ำ;
$lang['ajax_loading_tasklist']= เพิ่มงานรถหนีบกระดาษ;

/* End of file ftp_lang.php */
/* Location: ./system/language/english/clamplift_lang.php 
 */
 




?>
