<?php

$lang['title']				= "Products | Likitomi ERP";
$lang['all_products']		= "All Products";
$lang['search_result']		="Search Result";

$lang['msg_selectproducts']	= "Select Products from left menus";
$lang['msg_nothingtoedit']	= "Nothing to Edit. Please select one of the products.";
$lang['msg_nothingtodelete']	= "Nothing to Delete. Please select one of the products.";
$lang['ajax_loading_products'] = "Loading Products..";
$lang['ajax_loading_details'] = "Loading Product Details..";
$lang['ajax_updating_details'] = "Updating Product Details..";
$lang['ajax_saving_details'] = "Saving Product Details..";

$lang['search_products']	="Search Products...";
$lang['created_on']			="Created";
$lang['modified_on']		="Modified";


//Buttons
$lang['edit'] 		= "Edit";
$lang['update'] 	= "Update";
$lang['cancel'] 	= "Cancel";
$lang['save'] 		= "Save";
$lang['archive'] 	= "Archive";
$lang['add'] 		= "Add";


?>
