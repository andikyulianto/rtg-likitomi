<?php

$lang['title']				= "Planning | Likitomi ERP";
?>