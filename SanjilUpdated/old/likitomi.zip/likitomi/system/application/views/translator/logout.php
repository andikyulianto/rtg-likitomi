<div class="auto form">
	<a href="/login/logout">Click here to logout</a>
</div>
