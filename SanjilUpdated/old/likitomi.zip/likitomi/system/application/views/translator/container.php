<?php
$this->load->view('translator/header', $page_title);
$this->load->view($page_content);
$this->load->view('translator/footer');
?> 
