<div id="sales" class="x-hide-display paddedDiv">
<?php
	$this->load->view('salesorder/salesorderdiv');
?>
</div>