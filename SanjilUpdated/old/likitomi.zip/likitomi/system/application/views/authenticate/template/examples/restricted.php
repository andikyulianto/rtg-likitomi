<h2>You can view this message because your webmaster allowed you to.</h2>

<br /><br /><?=anchor('example', 'back to the list')?>
