<?=$this->lang->line('FAL_forgotten_password_reset_success_message');?>
<br />
<br />
<?=anchor($this->config->item('FAL_changePassword_uri'), $this->lang->line('FAL_continue_label'))?>

