<?=$welcome?>! / <?=anchor($login_uri, $login_label, $login_attributes)?>
