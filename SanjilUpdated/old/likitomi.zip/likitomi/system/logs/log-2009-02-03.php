<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-03 15:37:41 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2009-02-03 15:37:42 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2009-02-03 15:37:42 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2009-02-03 15:37:44 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2009-02-03 15:37:44 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
ERROR - 2009-02-03 15:38:18 --> Severity: Warning  --> Invalid argument supplied for foreach() C:\wamp\www\likitomi\system\application\controllers\planning.php 145
ERROR - 2009-02-03 15:40:43 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 54
ERROR - 2009-02-03 15:40:43 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatordaily.php 55
