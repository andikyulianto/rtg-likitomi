<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-25 08:31:46 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2009-02-25 08:31:46 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\totalproductionplan.php 48
ERROR - 2009-02-25 08:31:51 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 56
ERROR - 2009-02-25 08:31:51 --> Severity: Warning  --> Division by zero C:\wamp\www\likitomi\system\application\views\planning\corrugatorclamplift.php 57
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 09:10:15 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 09:30:05 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 10:25:03 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 10:25:04 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 15:00:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 15:08:41 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-25 15:21:07 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
