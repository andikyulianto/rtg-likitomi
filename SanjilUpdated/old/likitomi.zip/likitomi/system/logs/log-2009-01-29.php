<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-01-29 10:17:16 --> 404 Page Not Found --> users/2
ERROR - 2009-01-29 10:17:22 --> 404 Page Not Found --> users/4
ERROR - 2009-01-29 10:17:27 --> 404 Page Not Found --> users/2
