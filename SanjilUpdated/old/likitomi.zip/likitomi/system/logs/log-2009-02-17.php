<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 16:06:31 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 16:13:32 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 16:18:36 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 16:54:29 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:29 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:29 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:29 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:54 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:54 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:54 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:54 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:54 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:54 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 3
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 5
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 6
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 7
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 8
ERROR - 2009-02-17 16:54:57 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 9
ERROR - 2009-02-17 16:55:29 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:29 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:29 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:29 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:29 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:29 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:48 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:48 --> Severity: Notice  --> Use of undefined constant เดี๋ยวนี้ - assumed 'เดี๋ยวนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:48 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:48 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:48 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:48 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:48 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เดี๋ยวนี้ - assumed 'เดี๋ยวนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 3
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เดี๋ยวนี้ - assumed 'เดี๋ยวนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 4
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 5
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 6
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 7
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 8
ERROR - 2009-02-17 16:55:49 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 9
ERROR - 2009-02-17 16:56:00 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:00 --> Severity: Notice  --> Use of undefined constant เดี๋ยวนี้ - assumed 'เดี๋ยวนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:00 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:00 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:00 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:00 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:00 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:07 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:07 --> Severity: Notice  --> Use of undefined constant ขณะนี้ - assumed 'ขณะนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:07 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:07 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:07 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:07 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:07 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant ขณะนี้ - assumed 'ขณะนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 1
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant ระบบการทำงานรถหนีบกระดาษ - assumed 'ระบบการทำงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 3
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant ขณะนี้ - assumed 'ขณะนี้' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 4
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant เช้า - assumed 'เช้า' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 5
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant บ่าย - assumed 'บ่าย' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 6
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant เย็น - assumed 'เย็น' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 7
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant ค่ำ - assumed 'ค่ำ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 8
ERROR - 2009-02-17 16:56:09 --> Severity: Notice  --> Use of undefined constant เพิ่มงานรถหนีบกระดาษ - assumed 'เพิ่มงานรถหนีบกระดาษ' C:\wamp\www\likitomi\system\application\controllers\translator.php(536) : eval()'d code 9
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 17:34:27 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:14:12 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:14:22 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:16:51 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:16:58 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:18:46 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:20:02 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 4
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 6
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 7
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: customer_name C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 8
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: partner_isdeleted C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 9
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Undefined variable: resultProductCatalog C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
ERROR - 2009-02-17 18:21:35 --> Severity: Notice  --> Trying to get property of non-object C:\wamp\www\likitomi\system\application\views\products\productsaleshistory.php 12
